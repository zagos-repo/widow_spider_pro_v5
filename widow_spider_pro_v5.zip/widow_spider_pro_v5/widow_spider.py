#!/usr/bin/env python3
"""Widow Spider Pro 5.0: source-traceable public-web research. No account access or identity inference."""
import argparse, html, json, os, re, sys, urllib.parse, urllib.request, urllib.error, math
from pathlib import Path
from datetime import datetime, timezone
from collections import OrderedDict, Counter
from urllib.parse import urlparse

VERSION = "5.0.0"
ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
BANNER = r'''\033[96m
██╗    ██╗██╗██████╗  ██████╗ ██╗    ██╗    ███████╗██████╗ ██╗██████╗ ███████╗██████╗
██║    ██║██║██╔══██╗██╔═══██╗██║    ██║    ██╔════╝██╔══██╗██║██╔══██╗██╔════╝██╔══██╗
██║ █╗ ██║██║██║  ██║██║   ██║██║ █╗ ██║    ███████╗██████╔╝██║██║  ██║█████╗  ██████╔╝
██║███╗██║██║██║  ██║██║   ██║██║███╗██║    ╚════██║██╔═══╝ ██║██║  ██║██╔══╝  ██╔══██╗
╚███╔███╔╝██║██████╔╝╚██████╔╝██║  ██║    ███████║██║     ██║██████╔╝███████║██║  ██║
 ╚══╝╚══╝ ╚═╝╚═════╝  ╚═════╝  ╚══════╝    ╚══════╝╚══════╝ ╚═╝╚═════╝ ╚══════╝
                      PRO 5.0 | PUBLIC-SOURCE INTELLIGENCE\033[0m'''

def safe_name(s): return re.sub(r'[^A-Za-z0-9._-]+','_',s.strip())[:55] or 'query'
def validate(kind, value):
    value=value.strip()
    if not value: raise ValueError('Search value cannot be empty.')
    if kind=='username':
        value=value.lstrip('@')
        if not re.fullmatch(r'[A-Za-z0-9._-]{1,64}',value): raise ValueError('Username: use 1–64 letters, numbers, dots, underscores or hyphens.')
    elif kind=='email' and not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',value): raise ValueError('Email format is invalid.')
    elif kind=='phone' and (not re.fullmatch(r'\+?[0-9().\-\s]{7,24}',value) or not 7<=len(re.sub(r'\D','',value))<=15): raise ValueError('Phone should contain 7–15 digits.')
    return value

def query_variants(kind, value, extra=None):
    q=value.strip(); qs=[]
    if kind=='username':
        qs=[f'"{q}"',f'"{q}" (profile OR username OR portfolio)',f'"{q}" (GitHub OR LinkedIn OR blog)',
             f'"{q}" site:facebook.com',f'"{q}" site:instagram.com',f'"{q}" site:linkedin.com',
             f'"{q}" site:x.com',f'"{q}" site:tiktok.com',f'"{q}" site:youtube.com']
    elif kind=='email':
        qs=[f'"{q}"',f'"{q}" (contact OR profile OR publication)',
             f'"{q}" site:facebook.com',f'"{q}" site:instagram.com',
             f'"{q}" site:github.com',f'"{q}" site:linkedin.com']
    elif kind=='phone':
        digits=re.sub(r'\D','',q)
        qs=list(dict.fromkeys([f'"{q}"',f'"{digits}"']))
    else:
        qs=[q, f'"{q}"']
    if extra:
        for x in extra: qs.append(f'"{q}" site:{x}')
    return list(dict.fromkeys(qs))

def search_web(query, count):
    key=os.getenv('BRAVE_SEARCH_API_KEY','').strip()
    if not key: raise RuntimeError('BRAVE_SEARCH_API_KEY is not set. See README_AR.md.')
    params=urllib.parse.urlencode({'q':query,'count':max(1,min(count,20)),'safesearch':'moderate'})
    req=urllib.request.Request('https://api.search.brave.com/res/v1/web/search?'+params,
       headers={'Accept':'application/json','X-Subscription-Token':key,'User-Agent':'WidowSpiderPro/4.0'})
    try:
        with urllib.request.urlopen(req,timeout=30) as r: data=json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        if e.code==401: raise RuntimeError('Brave API rejected the key (401). Check the key/account.')
        if e.code==403: raise RuntimeError('Brave API denied this request (403). Check plan and API permissions.')
        if e.code==429: raise RuntimeError('Brave API quota/rate limit reached (429). Try later or review plan.')
        raise RuntimeError(f'Brave API HTTP error: {e.code}')
    except Exception as e: raise RuntimeError(f'Network/API error: {e}')
    out=[]
    for x in data.get('web',{}).get('results',[]):
        url=x.get('url','').strip()
        if not url.startswith(('http://','https://')): continue
        p=urlparse(url)
        out.append({'title':x.get('title','').strip(),'url':url,'description':x.get('description','').strip(),
          'domain':(p.hostname or '').lower().removeprefix('www.'),'provider':'Brave Search API','matched_queries':[query],
          'published_hint':x.get('page_age') or x.get('age') or '', 'language_hint':x.get('language',''),
          'status':'Unverified public-source lead'})
    return out


def search_google(query, count):
    """Google Programmable Search JSON API; requires GOOGLE_CSE_API_KEY and GOOGLE_CSE_ID."""
    key=os.getenv('GOOGLE_CSE_API_KEY','').strip()
    cx=os.getenv('GOOGLE_CSE_ID','').strip()
    if not key or not cx:
        raise RuntimeError('Google engine needs GOOGLE_CSE_API_KEY and GOOGLE_CSE_ID. See README.md.')
    params=urllib.parse.urlencode({'key':key,'cx':cx,'q':query,'num':max(1,min(count,10)),'safe':'active'})
    req=urllib.request.Request('https://www.googleapis.com/customsearch/v1?'+params,
       headers={'Accept':'application/json','User-Agent':'WidowSpiderPro/5.0'})
    try:
        with urllib.request.urlopen(req,timeout=30) as r: data=json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        if e.code==400: raise RuntimeError('Google CSE request invalid (400). Check the engine ID/settings.')
        if e.code==403: raise RuntimeError('Google CSE access/quota denied (403). Check key, API access and quota.')
        if e.code==429: raise RuntimeError('Google CSE rate limit reached (429).')
        raise RuntimeError(f'Google CSE HTTP error: {e.code}')
    except Exception as e: raise RuntimeError(f'Google CSE network/API error: {e}')
    out=[]
    for x in data.get('items',[]):
        url=x.get('link','').strip()
        if not url.startswith(('http://','https://')): continue
        p=urlparse(url)
        out.append({'title':x.get('title','').strip(),'url':url,'description':x.get('snippet','').strip(),
          'domain':(p.hostname or '').lower().removeprefix('www.'),'provider':'Google Programmable Search',
          'matched_queries':[query],'published_hint':'','language_hint':'','status':'Unverified public-source lead'})
    return out

def score_result(kind,value,r):
    # A transparent lexical relevance aid only; explicitly not identity confidence.
    target=value.casefold().strip(); title=r.get('title','').casefold(); desc=r.get('description','').casefold(); url=r.get('url','').casefold()
    hay=' '.join((title,desc,url)); score=0; reasons=[]
    if target and target in hay: score+=45; reasons.append('exact input string appears in result text')
    tokens=[t for t in re.findall(r'[\w@.+-]+',target) if len(t)>2]
    overlap=[t for t in tokens if t in hay]
    if tokens:
        add=round(30*len(set(overlap))/len(set(tokens))); score+=add
        if overlap: reasons.append(f'{len(set(overlap))}/{len(set(tokens))} input tokens appear')
    if target and target in title: score+=15; reasons.append('input appears in title')
    if target and target in url: score+=10; reasons.append('input appears in URL')
    return min(100,score), reasons

def esc(x): return html.escape(str(x or ''),quote=True)

def save_report(kind,value,queries,results,errors):
    REPORTS.mkdir(exist_ok=True); now=datetime.now(timezone.utc); stamp=now.strftime('%Y%m%dT%H%M%SZ')
    stem=f'{stamp}_{kind}_{safe_name(value)}'; domains=Counter(r.get('domain','') for r in results if r.get('domain'))
    data={'tool':'Widow Spider Pro','version':VERSION,'created_utc':now.isoformat(),'search_type':kind,'input':value,
      'providers_used':sorted(set(p for r in results for p in r.get('providers',[r.get('provider','')]))),'queries_sent':queries,'query_errors':errors,'result_count':len(results),
      'unique_domain_count':len(domains),'domain_counts':domains.most_common(),
      'interpretation':'Public search results are leads, not proof of identity, ownership, or relationship. Relevance score is lexical only.',
      'results':results}
    jp=REPORTS/(stem+'.json'); jp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    # SVG graph: query -> result pages, and visually grouped domain labels. No inferred person-to-person edges.
    n=len(results); W=1200; H=max(620, min(1500, 170+((n+3)//4)*145)); rootx,rooty=130,H/2
    nodes=[]; edges=[]
    nodes.append(f'<g class="node root"><circle cx="{rootx}" cy="{rooty}" r="62"/><text x="{rootx}" y="{rooty-8}" text-anchor="middle">SEARCH INPUT</text><text x="{rootx}" y="{rooty+15}" text-anchor="middle">{esc(value[:22])}</text></g>')
    cols=4; startx=390; gapx=190; starty=80; gapy=145
    for i,r in enumerate(results):
        col=i%cols; row=i//cols; x=startx+col*gapx; y=starty+row*gapy
        if y>H-60: continue
        label=(r.get('domain') or r.get('title') or 'Result')[:25]
        edges.append(f'<path class="edge" d="M {rootx+60} {rooty} C 280 {rooty}, 290 {y}, {x-48} {y}"/>')
        nodes.append(f'<a href="{esc(r.get("url"))}" target="_blank" rel="noopener noreferrer"><g class="node source"><circle cx="{x}" cy="{y}" r="42"/><text x="{x}" y="{y-4}" text-anchor="middle">SOURCE {i+1:02}</text><text x="{x}" y="{y+14}" text-anchor="middle">{esc(label[:18])}</text></g></a>')
    cards=[]
    for i,r in enumerate(results,1):
        cards.append(f'''<article class="result" data-search="{esc((r.get('title','')+' '+r.get('description','')+' '+r.get('domain','')).lower())}">
<div class="cardtop"><span>LEAD {i:03}</span><span class="score">TEXT RELEVANCE {r.get('relevance_score',0)}/100</span></div>
<h3>{esc(r.get('title') or '(Untitled result)')}</h3><p>{esc(r.get('description') or 'No description supplied by the search provider.')}</p>
<div class="meta"><b>{esc(r.get('domain'))}</b><span>{esc(', '.join(r.get('providers',[r.get('provider','')])) )}</span></div><a class="url" href="{esc(r.get('url'))}" target="_blank" rel="noopener noreferrer">{esc(r.get('url'))}</a>
<div class="chips">{''.join('<span>'+esc(q)+'</span>' for q in r.get('matched_queries',[]))}</div>
<details><summary>Evidence & interpretation</summary><p>Matched query: {esc('; '.join(r.get('matched_queries',[])))}</p><p>Scoring reasons: {esc('; '.join(r.get('score_reasons',[])) or 'No strong lexical match found.')}</p><p>Published-date hint: {esc(r.get('published_hint') or 'Not provided')}</p><p>Language hint: {esc(r.get('language_hint') or 'Not provided')}</p></details><span class="flag">UNVERIFIED PUBLIC LEAD</span></article>''')
    domain_rows=''.join(f'<tr><td>{esc(d)}</td><td>{c}</td></tr>' for d,c in domains.most_common()) or '<tr><td colspan="2">No domains returned</td></tr>'
    query_rows=''.join(f'<li><code>{esc(q)}</code></li>' for q in queries)
    error_html=''.join(f'<li>{esc(e)}</li>' for e in errors) or '<li>No query-level errors reported.</li>'
    doc=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Widow Spider Pro 5.0 — Intelligence Report</title><style>
:root{{--bg:#050a13;--panel:#0b1627;--line:#1b3554;--cyan:#57e7ee;--violet:#b49aff;--text:#eaf3ff;--muted:#91a7c2;--amber:#ffc66d}}*{{box-sizing:border-box}}body{{margin:0;background:radial-gradient(ellipse at 15% 0%,#12304d 0,transparent 40%),linear-gradient(145deg,#050a13,#091322 60%,#100e26);color:var(--text);font:14px Inter,Segoe UI,system-ui,sans-serif}}main{{max-width:1500px;margin:auto;padding:24px}}.hero,.panel,.metric{{border:1px solid var(--line);background:#0a1627dd;border-radius:18px}}.hero{{padding:26px;display:flex;justify-content:space-between;gap:20px;align-items:center;box-shadow:0 20px 70px #0005}}.brand{{color:var(--cyan);font-size:12px;font-weight:900;letter-spacing:.2em}}h1{{font-size:clamp(25px,4vw,40px);margin:10px 0}}.muted,.hint{{color:var(--muted);line-height:1.7}}.pill,.flag{{border:1px solid #32636e;color:var(--cyan);border-radius:99px;padding:8px 12px;font-size:11px;white-space:nowrap}}.metrics{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:15px 0}}.metric{{padding:16px}}.metric strong{{display:block;color:var(--cyan);font-size:25px}}.metric small{{color:var(--muted);letter-spacing:.09em;text-transform:uppercase}}.panel{{margin-top:16px;overflow:hidden}}.head{{padding:17px 20px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;gap:12px;align-items:center}}h2{{font-size:16px;margin:0}}.graph{{overflow:auto;background-image:radial-gradient(#24405c 1px,transparent 1px);background-size:22px 22px}}svg{{display:block;width:100%;min-width:900px;height:auto}}.edge{{fill:none;stroke:#3e8ba4;stroke-width:1.4;opacity:.7;stroke-dasharray:5 6;animation:dash 24s linear infinite}}@keyframes dash{{to{{stroke-dashoffset:-400}}}}.node circle{{fill:#101d35;stroke:var(--cyan);stroke-width:1.5;filter:drop-shadow(0 0 8px #42dce655)}}.root circle{{fill:#172348;stroke:var(--violet);stroke-width:2.4}}.node text{{fill:#c6faff;font-size:10px;font-weight:700;pointer-events:none}}.source:hover circle{{fill:#173b4a;stroke:#fff}}.toolbar{{display:flex;gap:12px;align-items:center;padding:14px 18px;flex-wrap:wrap}}input{{background:#07101d;border:1px solid #294561;border-radius:10px;padding:12px;color:var(--text);min-width:250px;flex:1}}.cards{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;padding:14px}}.result{{background:linear-gradient(145deg,#0d1b2e,#081321);border:1px solid var(--line);border-radius:14px;padding:17px;overflow-wrap:anywhere}}.cardtop,.meta{{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;font-size:11px;color:var(--cyan);letter-spacing:.07em}}.score{{color:var(--violet)}}h3{{font-size:17px;line-height:1.45}}.result p{{color:#b8c8db;line-height:1.7}}.meta{{color:var(--muted);margin:14px 0 7px}}.meta b{{color:var(--cyan)}}.url{{color:#68e5ef;word-break:break-all}}.chips{{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px}}.chips span{{border:1px solid #2a3c60;border-radius:7px;padding:4px 7px;color:#b8c8db;font-size:10px}}details{{margin-top:12px;color:var(--muted)}}summary{{cursor:pointer}}.flag{{display:inline-block;margin-top:12px;color:var(--amber);border-color:#72562b;border-radius:7px}}.lower{{display:grid;grid-template-columns:1fr 1fr;gap:14px}}.inner{{padding:18px}}table{{width:100%;border-collapse:collapse}}td,th{{padding:9px;text-align:left;border-bottom:1px solid var(--line)}}th{{color:var(--cyan)}}li{{margin:7px 0;overflow-wrap:anywhere}}code{{color:#c7baff;white-space:pre-wrap;overflow-wrap:anywhere}}.notice{{padding:18px;color:var(--muted);line-height:1.8;border-top:1px solid var(--line)}}footer{{padding:22px 2px;color:var(--muted);font-size:12px}}@media(max-width:800px){{main{{padding:10px}}.hero{{align-items:flex-start;flex-direction:column}}.metrics{{grid-template-columns:repeat(2,1fr)}}.cards,.lower{{grid-template-columns:1fr}}}}
</style></head><body><main><header class="hero"><div><div class="brand">🕷 WIDOW SPIDER PRO / 5.0</div><h1>Public-Source Intelligence Report</h1><div class="muted">Search type: <b>{esc(kind)}</b> · Input: <b>{esc(value)}</b><br>Generated (UTC): {esc(now.isoformat())} · Search provider(s): {esc(', '.join(sorted(set(p for r in results for p in r.get('providers',[r.get('provider','')])))) or 'No provider results')}</div></div><div class="pill">SOURCE-TRACEABLE · PUBLIC WEB</div></header>
<section class="metrics"><div class="metric"><strong>{len(results)}</strong><small>Unique result pages</small></div><div class="metric"><strong>{len(domains)}</strong><small>Unique domains</small></div><div class="metric"><strong>{len(queries)}</strong><small>Queries attempted</small></div><div class="metric"><strong>{len(errors)}</strong><small>Query errors</small></div></section>
<section class="panel"><div class="head"><h2>◈ Source relationship map</h2><span class="hint">Each line means “returned by this search”; not a personal relationship.</span></div><div class="graph"><svg viewBox="0 0 {W} {H}" role="img" aria-label="Graph connecting the search input to public result pages"><defs><pattern id="dots" width="22" height="22" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r="1" fill="#25405b"/></pattern></defs><rect width="100%" height="100%" fill="url(#dots)"/>{''.join(edges)}{''.join(nodes)}</svg></div><div class="notice">The map is evidence navigation, not an identity graph. A shared username or contact string can refer to different people; verify claims against original sources.</div></section>
<section class="panel"><div class="head"><h2>◉ Social platform public-search shortcuts</h2></div><div class="inner"><p class="hint">Opens public web-search queries for these platforms. Indexing and visibility are controlled by the platform. No private-profile access or login bypass.</p><div class="chips"><a href="https://www.google.com/search?q={urllib.parse.quote(value + ' site:facebook.com')}" target="_blank" rel="noopener noreferrer">Facebook</a><a href="https://www.google.com/search?q={urllib.parse.quote(value + ' site:instagram.com')}" target="_blank" rel="noopener noreferrer">Instagram</a><a href="https://www.google.com/search?q={urllib.parse.quote(value + ' site:linkedin.com')}" target="_blank" rel="noopener noreferrer">LinkedIn</a><a href="https://www.google.com/search?q={urllib.parse.quote(value + ' site:tiktok.com')}" target="_blank" rel="noopener noreferrer">TikTok</a><a href="https://www.google.com/search?q={urllib.parse.quote(value + ' site:youtube.com')}" target="_blank" rel="noopener noreferrer">YouTube</a></div></div></section>
<section class="panel"><div class="head"><h2>▤ Evidence records</h2><span class="hint">Filter title, snippet, domain, or URL</span></div><div class="toolbar"><input id="filter" type="search" placeholder="Filter results…"><span class="hint" id="visible">{len(results)} results</span></div><div class="cards" id="cards">{''.join(cards) if cards else '<p class="muted">No public results were returned. Try a broader query or check API access.</p>'}</div><div class="notice"><b>Scoring note:</b> Text relevance is an explainable string-matching aid, not an identity-confidence score. Search results may be stale, duplicated, incomplete, or unrelated.</div></section>
<div class="lower"><section class="panel"><div class="head"><h2>Domain distribution</h2></div><div class="inner"><table><thead><tr><th>Domain</th><th>Pages</th></tr></thead><tbody>{domain_rows}</tbody></table></div></section><section class="panel"><div class="head"><h2>Search audit trail</h2></div><div class="inner"><b>Queries sent</b><ol>{query_rows}</ol><b>Query-level errors</b><ul>{error_html}</ul></div></section></div>
<footer>WIDOW SPIDER PRO 5.0 · JSON companion report: same timestamp in reports/ · Keep reports private when queries contain contact details.</footer></main><script>const f=document.getElementById('filter'),cards=[...document.querySelectorAll('.result')],v=document.getElementById('visible');f.addEventListener('input',()=>{{let n=0,q=f.value.toLowerCase();cards.forEach(c=>{{let show=c.dataset.search.includes(q);c.style.display=show?'':'none';if(show)n++}});v.textContent=n+' visible results'}});</script></body></html>'''
    hp=REPORTS/(stem+'.html'); hp.write_text(doc,encoding='utf-8'); return jp,hp

def main():
    print(BANNER)
    p=argparse.ArgumentParser(description='Widow Spider Pro 5.0 — lawful public-source OSINT')
    sub=p.add_subparsers(dest='command',required=True)
    for name,desc in [('username','Search a public username string'),('email','Search a public email string'),('phone','Search a public phone string'),('google','General public web search')]:
        sp=sub.add_parser(name,help=desc); sp.add_argument('value'); sp.add_argument('--count',type=int,default=10,help='Results per query (1–20; Google max 10)'); sp.add_argument('--engine',choices=['brave','google','both'],default='brave',help='Search provider'); sp.add_argument('--site',action='append',default=[],help='Add a domain-focused query, e.g. --site github.com (repeatable)'); sp.add_argument('--json',action='store_true',help='Print machine-readable results to terminal')
    a=p.parse_args()
    if not 1<=a.count<=20: print('[!] --count must be between 1 and 20.',file=sys.stderr); return 2
    try:
        value=validate(a.command,a.value); queries=query_variants(a.command,value,a.site)
        print(f'[+] Strategy: {len(queries)} focused public-web queries; engine={a.engine}; up to {a.count} results/query.')
        merged=OrderedDict(); errors=[]
        for i,q in enumerate(queries,1):
            print(f'[{i}/{len(queries)}] Searching: {q}')
            try:
                found=[]
                engines = ['brave','google'] if a.engine=='both' else [a.engine]
                for engine in engines:
                    try:
                        batch = search_web(q,a.count) if engine=='brave' else search_google(q,a.count)
                        found.extend(batch)
                        print(f'    {engine}: returned {len(batch)} page(s)')
                    except RuntimeError as eng_err:
                        errors.append({'query':q,'error':f'{engine}: {eng_err}'})
                        print(f'    [!] {engine}: {eng_err}',file=sys.stderr)
                        if a.engine != 'both' and ('not set' in str(eng_err) or 'needs ' in str(eng_err)): raise
                for r in found:
                    key=r['url'].rstrip('/').casefold()
                    if key in merged:
                        if q not in merged[key]['matched_queries']: merged[key]['matched_queries'].append(q)
                        oldprov=merged[key].get('providers',[merged[key].get('provider','')])
                        if r.get('provider') not in oldprov: oldprov.append(r.get('provider'))
                        merged[key]['providers']=oldprov
                    else:
                        r['providers']=[r.get('provider','')]
                        merged[key]=r
            except RuntimeError as e:
                errors.append({'query':q,'error':str(e)}); print(f'    [!] {e}',file=sys.stderr)
                if 'BRAVE_SEARCH_API_KEY' in str(e): raise
        results=list(merged.values())
        for r in results:
            r['relevance_score'],r['score_reasons']=score_result(a.command,value,r)
        results.sort(key=lambda r:(r['relevance_score'],len(r['matched_queries']),bool(r['url'])),reverse=True)
        simple_errors=[f"{x['query']}: {x['error']}" for x in errors]
        jp,hp=save_report(a.command,value,queries,results,simple_errors)
    except (ValueError,RuntimeError) as e: print('[!] '+str(e),file=sys.stderr); return 2
    except KeyboardInterrupt: print('\n[!] Cancelled.'); return 130
    except Exception as e: print('[!] Unexpected failure: '+str(e),file=sys.stderr); return 1
    if a.json: print(json.dumps(results,ensure_ascii=False,indent=2))
    else:
        print('\n'+'='*78+'\n RESULTS SUMMARY\n'+'='*78)
        for i,r in enumerate(results,1):
            print(f"\n[{i:03}] TEXT RELEVANCE {r['relevance_score']}/100 | {r.get('domain','')}")
            print('Title:  '+(r.get('title') or '(untitled)'))
            print('URL:    '+r['url'])
            print('Detail: '+(r.get('description') or '(no snippet provided)'))
            print('Found by: '+' | '.join(r['matched_queries']))
            print('Why ranked: '+'; '.join(r['score_reasons']))
            print('Status: UNVERIFIED PUBLIC-SOURCE LEAD')
    print('\n'+'='*78); print(f'[+] Unique pages: {len(results)} | Unique domains: {len(set(r.get("domain") for r in results))}')
    print(f'[+] JSON report: {jp}\n[+] Interactive HTML report: {hp}')
    print('[i] Scores are lexical relevance only. Search results do not prove identity, ownership, or personal relationships.')
    return 0
if __name__=='__main__': raise SystemExit(main())
