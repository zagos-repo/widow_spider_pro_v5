# Widow Spider Pro 5.0 — Public-source research

## Features
- Multi-query research for username, email, phone strings, and general topics.
- Search providers: Brave Search API, Google Programmable Search JSON API, or both.
- Public indexed queries for Facebook, Instagram, LinkedIn, X, TikTok, YouTube and GitHub.
- Deduplication, lexical relevance explanations, domain statistics, JSON and interactive HTML report with source navigation graph.
- Graph edges mean “returned by this search query”; they do not imply a personal relationship.

## Windows / VS Code
Python 3.10+ recommended. Open folder in VS Code and run in PowerShell:
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
$env:BRAVE_SEARCH_API_KEY = "YOUR_BRAVE_KEY"
python .\widow_spider.py --help
python .\widow_spider.py username "example_user" --engine brave --count 10
```
Brave key: https://api-dashboard.search.brave.com/

## Google setup
Google Programmable Search requires an API key and Search Engine ID (`cx`):
```powershell
$env:GOOGLE_CSE_API_KEY = "YOUR_GOOGLE_API_KEY"
$env:GOOGLE_CSE_ID = "YOUR_SEARCH_ENGINE_ID"
python .\widow_spider.py username "example_user" --engine google --count 10
```
Use `--engine both` after configuring both providers. Google API returns up to 10 results per request.
Official docs: https://developers.google.com/custom-search/v1/overview
Create/configure engine: https://programmablesearchengine.google.com/

## Examples
```powershell
python .\widow_spider.py username "example_user" --engine both --count 10
python .\widow_spider.py email "public@example.com" --engine brave
python .\widow_spider.py phone "+212612345678" --engine google
python .\widow_spider.py google "cybersecurity Morocco" --engine both
python .\widow_spider.py username "example_user" --site github.com --site linkedin.com
python .\widow_spider.py username "example_user" --json
```
Reports are saved in `reports/` as `.html` and `.json`.

## Accuracy, limitations, responsible use
Search engines only index some public pages; results can be stale, incomplete, or irrelevant. Scores measure textual relevance, not identity confidence. Matching a username, email or phone string is not proof that profiles belong to one person. Social platform search shortcuts only query public/indexed pages. This tool does not log in to accounts, access private profiles, scrape non-public content, bypass access controls, or circumvent rate limits. Use only for lawful, consent-based/public-interest research; protect reports containing contact details.
